# 2018-live-poll-results
Data from the 2018 [New York Times Upshot/Siena College live polls](https://www.nytimes.com/interactive/2018/upshot/elections-polls.html)


